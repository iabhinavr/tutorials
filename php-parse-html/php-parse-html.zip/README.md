# Topics in this tutorial

- selecting elements by id
- selecting elements using tagname
- selecting elements using xpath query
- create and insert new elements into the page
- delete an element from the page
- getting element attribute values
- setting attribute values